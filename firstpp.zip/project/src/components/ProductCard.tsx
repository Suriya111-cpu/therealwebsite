import React from 'react';
import { ShoppingCart, Heart, Eye } from 'lucide-react';
import { Product } from '../types';
import { formatPrice } from '../utils/formatters';

interface ProductCardProps {
  product: Product;
  addToCart: (product: Product) => void;
  openProductDetail: (product: Product) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, addToCart, openProductDetail }) => {
  return (
    <div className="bg-gray-800 rounded-lg shadow-lg overflow-hidden hover:shadow-purple-700/20 hover:shadow-xl transition-shadow duration-300 border border-gray-700">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
        <button 
          className="absolute top-2 right-2 p-1.5 bg-gray-900/80 rounded-full shadow-md hover:bg-purple-900/80 transition"
          aria-label="Add to wishlist"
        >
          <Heart className="h-5 w-5 text-purple-400" />
        </button>
      </div>
      
      <div className="p-4">
        <h3 className="text-lg font-semibold text-white mb-1">{product.name}</h3>
        <p className="text-gray-400 text-sm mb-2 line-clamp-2">{product.description}</p>
        
        <div className="flex items-center justify-between mt-3">
          <span className="text-xl font-bold text-purple-400">{formatPrice(product.price)}</span>
          
          <div className="flex space-x-2">
            <button 
              onClick={() => openProductDetail(product)}
              className="p-2 bg-gray-700 rounded-full hover:bg-gray-600 transition"
              aria-label="View details"
            >
              <Eye className="h-5 w-5 text-gray-200" />
            </button>
            
            <button 
              onClick={() => addToCart(product)}
              className="p-2 bg-purple-700 rounded-full hover:bg-purple-600 transition"
              aria-label="Add to cart"
            >
              <ShoppingCart className="h-5 w-5 text-white" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;