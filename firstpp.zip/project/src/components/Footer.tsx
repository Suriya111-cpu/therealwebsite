import React from 'react';
import { Package, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Youtube } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black text-white border-t border-purple-900">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <img src="/logo.png" alt="EzBuild Logo" className="h-8 w-auto" />
              <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-purple-300 text-transparent bg-clip-text">EzBuild</span>
            </div>
            <p className="text-gray-400 mb-4">
              Your one-stop destination for premium gaming PCs at competitive prices.
              Build your dream gaming setup with our high-performance custom builds.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-purple-400 transition">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-purple-400 transition">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-purple-400 transition">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-purple-400 transition">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4 text-purple-400">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-purple-400 transition">Home</a></li>
              <li><a href="#featured" className="text-gray-400 hover:text-purple-400 transition">Featured PCs</a></li>
              <li><a href="#products" className="text-gray-400 hover:text-purple-400 transition">All Products</a></li>
              <li><a href="#" className="text-gray-400 hover:text-purple-400 transition">About Us</a></li>
              <li><a href="#" className="text-gray-400 hover:text-purple-400 transition">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4 text-purple-400">Customer Service</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-purple-400 transition">My Account</a></li>
              <li><a href="#" className="text-gray-400 hover:text-purple-400 transition">Track Order</a></li>
              <li><a href="#" className="text-gray-400 hover:text-purple-400 transition">Shipping Policy</a></li>
              <li><a href="#" className="text-gray-400 hover:text-purple-400 transition">Returns & Refunds</a></li>
              <li><a href="#" className="text-gray-400 hover:text-purple-400 transition">FAQs</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4 text-purple-400">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 text-purple-400 mt-0.5" />
                <span className="text-gray-400">123 Tech Street, Bangalore, Karnataka, India - 560001</span>
              </li>
              <li className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-purple-400" />
                <span className="text-gray-400">+91 98765 43210</span>
              </li>
              <li className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-purple-400" />
                <span className="text-gray-400">support@ezbuild.in</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} EzBuild. All rights reserved.
          </p>
          <div className="flex space-x-4">
            <a href="#" className="text-gray-400 hover:text-purple-400 transition text-sm">Privacy Policy</a>
            <a href="#" className="text-gray-400 hover:text-purple-400 transition text-sm">Terms of Service</a>
            <a href="#" className="text-gray-400 hover:text-purple-400 transition text-sm">Sitemap</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;