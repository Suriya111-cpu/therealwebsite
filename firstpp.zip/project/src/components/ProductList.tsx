import React, { useState } from 'react';
import { products } from '../data/products';
import { Product } from '../types';
import ProductCard from './ProductCard';
import ProductDetail from './ProductDetail';

interface ProductListProps {
  addToCart: (product: Product) => void;
}

const ProductList: React.FC<ProductListProps> = ({ addToCart }) => {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const openProductDetail = (product: Product) => {
    setSelectedProduct(product);
  };

  const closeProductDetail = () => {
    setSelectedProduct(null);
  };

  return (
    <div id="products">
      <h2 className="text-2xl font-bold mb-6 text-purple-400">All Gaming PCs</h2>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {products.map(product => (
          <ProductCard 
            key={product.id} 
            product={product} 
            addToCart={addToCart}
            openProductDetail={openProductDetail}
          />
        ))}
      </div>

      {selectedProduct && (
        <ProductDetail 
          product={selectedProduct} 
          closeProductDetail={closeProductDetail}
          addToCart={addToCart}
        />
      )}
    </div>
  );
};

export default ProductList;