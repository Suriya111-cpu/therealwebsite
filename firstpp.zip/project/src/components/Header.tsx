import React, { useState } from 'react';
import { ShoppingCart, Search, Menu, X, Home, Package, User, Phone } from 'lucide-react';

interface HeaderProps {
  cartItemCount: number;
  toggleCart: () => void;
}

const Header: React.FC<HeaderProps> = ({ cartItemCount, toggleCart }) => {
  const [showMenu, setShowMenu] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const toggleMenu = () => {
    setShowMenu(!showMenu);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Searching for:', searchQuery);
    // Implement search functionality
  };

  return (
    <header className="bg-black text-white shadow-md border-b border-purple-700">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <img src="/logo.png" alt="EzBuild Logo" className="h-10 w-auto" />
            <span className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-purple-300 text-transparent bg-clip-text">EzBuild</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <a href="#" className="flex items-center space-x-1 text-gray-300 hover:text-purple-400 transition">
              <Home className="h-5 w-5" />
              <span>Home</span>
            </a>
            <a href="#featured" className="flex items-center space-x-1 text-gray-300 hover:text-purple-400 transition">
              <Package className="h-5 w-5" />
              <span>Featured PCs</span>
            </a>
            <a href="#products" className="flex items-center space-x-1 text-gray-300 hover:text-purple-400 transition">
              <Package className="h-5 w-5" />
              <span>All Products</span>
            </a>
            <a href="#" className="flex items-center space-x-1 text-gray-300 hover:text-purple-400 transition">
              <User className="h-5 w-5" />
              <span>Account</span>
            </a>
            <a href="#" className="flex items-center space-x-1 text-gray-300 hover:text-purple-400 transition">
              <Phone className="h-5 w-5" />
              <span>Contact</span>
            </a>
          </nav>

          {/* Search Bar */}
          <div className="hidden md:block flex-grow max-w-md mx-4">
            <form onSubmit={handleSearch} className="flex">
              <input
                type="text"
                placeholder="Search for gaming PCs..."
                className="w-full px-4 py-2 rounded-l-md bg-gray-800 text-gray-100 border border-gray-700 focus:outline-none focus:border-purple-500"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <button 
                type="submit" 
                className="bg-purple-700 px-4 py-2 rounded-r-md hover:bg-purple-600 transition"
              >
                <Search className="h-5 w-5" />
              </button>
            </form>
          </div>

          {/* Cart Icon */}
          <div className="flex items-center">
            <button 
              onClick={toggleCart}
              className="relative p-2 hover:bg-purple-900 rounded-full transition"
            >
              <ShoppingCart className="h-6 w-6" />
              {cartItemCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-purple-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {cartItemCount}
                </span>
              )}
            </button>
            
            {/* Mobile Menu Button */}
            <button 
              className="ml-4 md:hidden p-2 hover:bg-purple-900 rounded-full transition"
              onClick={toggleMenu}
            >
              {showMenu ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Search Bar */}
        <div className="mt-3 md:hidden">
          <form onSubmit={handleSearch} className="flex">
            <input
              type="text"
              placeholder="Search for gaming PCs..."
              className="w-full px-4 py-2 rounded-l-md bg-gray-800 text-gray-100 border border-gray-700 focus:outline-none focus:border-purple-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <button 
              type="submit" 
              className="bg-purple-700 px-4 py-2 rounded-r-md hover:bg-purple-600 transition"
            >
              <Search className="h-5 w-5" />
            </button>
          </form>
        </div>

        {/* Mobile Navigation Menu */}
        {showMenu && (
          <nav className="mt-3 md:hidden bg-gray-800 rounded-md p-4 space-y-3">
            <a href="#" className="flex items-center space-x-2 text-gray-300 hover:text-purple-400 transition py-2">
              <Home className="h-5 w-5" />
              <span>Home</span>
            </a>
            <a href="#featured" className="flex items-center space-x-2 text-gray-300 hover:text-purple-400 transition py-2">
              <Package className="h-5 w-5" />
              <span>Featured PCs</span>
            </a>
            <a href="#products" className="flex items-center space-x-2 text-gray-300 hover:text-purple-400 transition py-2">
              <Package className="h-5 w-5" />
              <span>All Products</span>
            </a>
            <a href="#" className="flex items-center space-x-2 text-gray-300 hover:text-purple-400 transition py-2">
              <User className="h-5 w-5" />
              <span>Account</span>
            </a>
            <a href="#" className="flex items-center space-x-2 text-gray-300 hover:text-purple-400 transition py-2">
              <Phone className="h-5 w-5" />
              <span>Contact</span>
            </a>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;