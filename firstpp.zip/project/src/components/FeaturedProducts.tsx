import React, { useState } from 'react';
import { products } from '../data/products';
import { Product } from '../types';
import { formatPrice } from '../utils/formatters';
import { ShoppingCart, ChevronRight, Truck, CreditCard, MapPin } from 'lucide-react';

interface FeaturedProductsProps {
  addToCart: (product: Product) => void;
}

const FeaturedProducts: React.FC<FeaturedProductsProps> = ({ addToCart }) => {
  const featuredProducts = products.filter(product => 
    [1, 2, 3, 4].includes(product.id)
  );
  
  const [activeTab, setActiveTab] = useState(1);
  const [showShipping, setShowShipping] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  
  const activeProduct = featuredProducts.find(p => p.id === activeTab) || featuredProducts[0];
  
  const handleAddToCart = (product: Product) => {
    addToCart(product);
  };
  
  return (
    <div id="featured" className="mb-16">
      <h2 className="text-2xl font-bold mb-6 text-purple-400">Featured Gaming PCs</h2>
      
      <div className="bg-gray-800 rounded-lg shadow-lg overflow-hidden border border-purple-700">
        {/* Tabs */}
        <div className="flex border-b border-gray-700">
          {featuredProducts.map(product => (
            <button
              key={product.id}
              className={`px-4 py-3 text-sm md:text-base font-medium transition-colors duration-200 ${
                activeTab === product.id 
                  ? 'bg-purple-900 text-white border-b-2 border-purple-500' 
                  : 'text-gray-400 hover:text-purple-400 hover:bg-gray-700'
              }`}
              onClick={() => setActiveTab(product.id)}
            >
              {product.name}
            </button>
          ))}
        </div>
        
        {/* Content */}
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Product Image */}
            <div className="relative overflow-hidden rounded-lg border border-purple-800 bg-black">
              <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-purple-900/30 to-transparent z-10"></div>
              <img 
                src={activeProduct.image} 
                alt={activeProduct.name} 
                className="w-full h-auto object-cover"
              />
              <div className="absolute top-4 right-4 bg-purple-600 text-white px-3 py-1 rounded-full text-sm font-bold">
                Featured
              </div>
            </div>
            
            {/* Product Details */}
            <div>
              <h3 className="text-2xl font-bold text-white mb-2">{activeProduct.name}</h3>
              <p className="text-gray-300 mb-4">{activeProduct.description}</p>
              
              <div className="mb-6">
                <h4 className="text-lg font-semibold text-purple-400 mb-2">Specifications</h4>
                <ul className="space-y-2 text-gray-300 bg-gray-900 p-4 rounded-lg border border-gray-700">
                  <li className="flex">
                    <span className="font-medium w-24 text-gray-400">Processor:</span>
                    <span>{activeProduct.specs.processor}</span>
                  </li>
                  <li className="flex">
                    <span className="font-medium w-24 text-gray-400">Graphics:</span>
                    <span>{activeProduct.specs.graphics}</span>
                  </li>
                  <li className="flex">
                    <span className="font-medium w-24 text-gray-400">RAM:</span>
                    <span>{activeProduct.specs.ram}</span>
                  </li>
                  <li className="flex">
                    <span className="font-medium w-24 text-gray-400">Storage:</span>
                    <span>{activeProduct.specs.storage}</span>
                  </li>
                  <li className="flex">
                    <span className="font-medium w-24 text-gray-400">Cooling:</span>
                    <span>{activeProduct.specs.cooling}</span>
                  </li>
                </ul>
              </div>
              
              <div className="flex items-center justify-between mb-6">
                <span className="text-3xl font-bold text-purple-400">{formatPrice(activeProduct.price)}</span>
                
                <button 
                  onClick={() => handleAddToCart(activeProduct)}
                  className="flex items-center space-x-2 bg-purple-700 text-white px-6 py-3 rounded-lg hover:bg-purple-600 transition shadow-lg shadow-purple-700/30"
                >
                  <ShoppingCart className="h-5 w-5" />
                  <span>Add to Cart</span>
                </button>
              </div>
              
              {/* Shipping & Payment Accordions */}
              <div className="space-y-3">
                <div className="border border-gray-700 rounded-lg overflow-hidden">
                  <button 
                    className="w-full flex items-center justify-between p-4 bg-gray-800 hover:bg-gray-700 transition"
                    onClick={() => setShowShipping(!showShipping)}
                  >
                    <div className="flex items-center space-x-2">
                      <Truck className="h-5 w-5 text-purple-400" />
                      <span className="font-medium">Shipping Information</span>
                    </div>
                    <ChevronRight className={`h-5 w-5 transition-transform ${showShipping ? 'rotate-90' : ''}`} />
                  </button>
                  
                  {showShipping && (
                    <div className="p-4 bg-gray-900 border-t border-gray-700">
                      <form className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-400 mb-1">First Name</label>
                            <input type="text" className="w-full p-2 rounded bg-gray-800 border border-gray-700 text-white focus:border-purple-500 focus:outline-none" />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-400 mb-1">Last Name</label>
                            <input type="text" className="w-full p-2 rounded bg-gray-800 border border-gray-700 text-white focus:border-purple-500 focus:outline-none" />
                          </div>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-400 mb-1">Address</label>
                          <input type="text" className="w-full p-2 rounded bg-gray-800 border border-gray-700 text-white focus:border-purple-500 focus:outline-none" />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-400 mb-1">City</label>
                            <input type="text" className="w-full p-2 rounded bg-gray-800 border border-gray-700 text-white focus:border-purple-500 focus:outline-none" />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-400 mb-1">State</label>
                            <input type="text" className="w-full p-2 rounded bg-gray-800 border border-gray-700 text-white focus:border-purple-500 focus:outline-none" />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-400 mb-1">Postal Code</label>
                            <input type="text" className="w-full p-2 rounded bg-gray-800 border border-gray-700 text-white focus:border-purple-500 focus:outline-none" />
                          </div>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-400 mb-1">Phone Number</label>
                          <input type="tel" className="w-full p-2 rounded bg-gray-800 border border-gray-700 text-white focus:border-purple-500 focus:outline-none" />
                        </div>
                      </form>
                    </div>
                  )}
                </div>
                
                <div className="border border-gray-700 rounded-lg overflow-hidden">
                  <button 
                    className="w-full flex items-center justify-between p-4 bg-gray-800 hover:bg-gray-700 transition"
                    onClick={() => setShowPayment(!showPayment)}
                  >
                    <div className="flex items-center space-x-2">
                      <CreditCard className="h-5 w-5 text-purple-400" />
                      <span className="font-medium">Payment Method</span>
                    </div>
                    <ChevronRight className={`h-5 w-5 transition-transform ${showPayment ? 'rotate-90' : ''}`} />
                  </button>
                  
                  {showPayment && (
                    <div className="p-4 bg-gray-900 border-t border-gray-700">
                      <div className="space-y-4">
                        <div className="flex items-center space-x-3 p-3 bg-gray-800 rounded border border-gray-700">
                          <input type="radio" id="credit-card" name="payment-method" className="h-4 w-4 accent-purple-500" defaultChecked />
                          <label htmlFor="credit-card" className="flex-grow">Credit/Debit Card</label>
                          <div className="flex space-x-2">
                            <div className="h-6 w-10 bg-gray-600 rounded"></div>
                            <div className="h-6 w-10 bg-gray-600 rounded"></div>
                            <div className="h-6 w-10 bg-gray-600 rounded"></div>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-3 p-3 bg-gray-800 rounded border border-gray-700">
                          <input type="radio" id="upi" name="payment-method" className="h-4 w-4 accent-purple-500" />
                          <label htmlFor="upi" className="flex-grow">UPI</label>
                          <div className="h-6 w-10 bg-gray-600 rounded"></div>
                        </div>
                        
                        <div className="flex items-center space-x-3 p-3 bg-gray-800 rounded border border-gray-700">
                          <input type="radio" id="netbanking" name="payment-method" className="h-4 w-4 accent-purple-500" />
                          <label htmlFor="netbanking" className="flex-grow">Net Banking</label>
                          <div className="h-6 w-10 bg-gray-600 rounded"></div>
                        </div>
                        
                        <div className="flex items-center space-x-3 p-3 bg-gray-800 rounded border border-gray-700">
                          <input type="radio" id="cod" name="payment-method" className="h-4 w-4 accent-purple-500" />
                          <label htmlFor="cod" className="flex-grow">Cash on Delivery</label>
                          <div className="h-6 w-10 bg-gray-600 rounded"></div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FeaturedProducts;