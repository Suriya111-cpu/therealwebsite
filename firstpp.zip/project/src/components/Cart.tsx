import React from 'react';
import { X, ShoppingBag, Trash2 } from 'lucide-react';
import { Product } from '../types';
import { formatPrice } from '../utils/formatters';

interface CartProps {
  cartItems: Product[];
  removeFromCart: (productId: number) => void;
  closeCart: () => void;
}

const Cart: React.FC<CartProps> = ({ cartItems, removeFromCart, closeCart }) => {
  const totalPrice = cartItems.reduce((total, item) => total + item.price, 0);
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-80 flex justify-end z-50">
      <div className="bg-gray-800 w-full max-w-md h-full flex flex-col border-l border-purple-700">
        <div className="flex justify-between items-center p-4 border-b border-gray-700">
          <h2 className="text-xl font-bold text-white flex items-center">
            <ShoppingBag className="h-5 w-5 mr-2 text-purple-400" />
            Your Cart ({cartItems.length})
          </h2>
          <button 
            onClick={closeCart}
            className="p-1 hover:bg-gray-700 rounded-full transition"
          >
            <X className="h-6 w-6 text-gray-400" />
          </button>
        </div>
        
        <div className="flex-grow overflow-y-auto p-4">
          {cartItems.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-gray-400">
              <ShoppingBag className="h-16 w-16 mb-4 text-purple-500/50" />
              <p className="text-lg">Your cart is empty</p>
              <button 
                onClick={closeCart}
                className="mt-4 text-purple-400 hover:text-purple-300 transition"
              >
                Continue Shopping
              </button>
            </div>
          ) : (
            <ul className="space-y-4">
              {cartItems.map((item) => (
                <li key={item.id} className="flex items-center space-x-4 border-b border-gray-700 pb-4">
                  <img 
                    src={item.image} 
                    alt={item.name} 
                    className="w-20 h-20 object-cover rounded border border-gray-700"
                  />
                  <div className="flex-grow">
                    <h3 className="font-medium text-white">{item.name}</h3>
                    <p className="text-purple-400 font-bold">{formatPrice(item.price)}</p>
                  </div>
                  <button 
                    onClick={() => removeFromCart(item.id)}
                    className="p-1 hover:bg-red-900/50 rounded-full transition"
                    aria-label="Remove item"
                  >
                    <Trash2 className="h-5 w-5 text-red-400" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
        
        {cartItems.length > 0 && (
          <div className="p-4 border-t border-gray-700 bg-gray-900">
            <div className="flex justify-between items-center mb-4">
              <span className="text-gray-300">Subtotal</span>
              <span className="font-bold text-white">{formatPrice(totalPrice)}</span>
            </div>
            <div className="flex justify-between items-center mb-4">
              <span className="text-gray-300">Shipping</span>
              <span className="font-bold text-white">Free</span>
            </div>
            <div className="flex justify-between items-center mb-6 text-lg">
              <span className="font-medium text-white">Total</span>
              <span className="font-bold text-purple-400">{formatPrice(totalPrice)}</span>
            </div>
            <button className="w-full bg-purple-700 text-white py-3 rounded-lg hover:bg-purple-600 transition shadow-lg shadow-purple-700/30">
              Proceed to Checkout
            </button>
            <button 
              onClick={closeCart}
              className="w-full text-purple-400 py-2 mt-2 hover:text-purple-300 transition"
            >
              Continue Shopping
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Cart;