import React from 'react';
import { X, ShoppingCart } from 'lucide-react';
import { Product } from '../types';
import { formatPrice } from '../utils/formatters';

interface ProductDetailProps {
  product: Product;
  closeProductDetail: () => void;
  addToCart: (product: Product) => void;
}

const ProductDetail: React.FC<ProductDetailProps> = ({ product, closeProductDetail, addToCart }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto border border-purple-700">
        <div className="flex justify-between items-center p-4 border-b border-gray-700">
          <h2 className="text-2xl font-bold text-white">{product.name}</h2>
          <button 
            onClick={closeProductDetail}
            className="p-1 hover:bg-gray-700 rounded-full transition"
          >
            <X className="h-6 w-6 text-gray-400" />
          </button>
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <div className="relative rounded-lg overflow-hidden border border-gray-700">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-900/30 to-transparent"></div>
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-auto"
                />
              </div>
            </div>
            
            <div>
              <div className="mb-4">
                <h3 className="text-xl font-semibold text-purple-400 mb-2">Description</h3>
                <p className="text-gray-300">{product.description}</p>
              </div>
              
              <div className="mb-6">
                <h3 className="text-xl font-semibold text-purple-400 mb-2">Specifications</h3>
                <ul className="space-y-2 text-gray-300 bg-gray-900 p-4 rounded-lg border border-gray-700">
                  <li className="flex">
                    <span className="font-medium w-24 text-gray-400">Processor:</span>
                    <span>{product.specs.processor}</span>
                  </li>
                  <li className="flex">
                    <span className="font-medium w-24 text-gray-400">Graphics:</span>
                    <span>{product.specs.graphics}</span>
                  </li>
                  <li className="flex">
                    <span className="font-medium w-24 text-gray-400">RAM:</span>
                    <span>{product.specs.ram}</span>
                  </li>
                  <li className="flex">
                    <span className="font-medium w-24 text-gray-400">Storage:</span>
                    <span>{product.specs.storage}</span>
                  </li>
                  <li className="flex">
                    <span className="font-medium w-24 text-gray-400">Cooling:</span>
                    <span>{product.specs.cooling}</span>
                  </li>
                </ul>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-2xl font-bold text-purple-400">{formatPrice(product.price)}</span>
                
                <button 
                  onClick={() => {
                    addToCart(product);
                    closeProductDetail();
                  }}
                  className="flex items-center space-x-2 bg-purple-700 text-white px-4 py-2 rounded-lg hover:bg-purple-600 transition shadow-lg shadow-purple-700/30"
                >
                  <ShoppingCart className="h-5 w-5" />
                  <span>Add to Cart</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;