import React, { useState } from 'react';
import { ShoppingCart, Heart, Search, Menu, X, Home, Package, User, Phone } from 'lucide-react';
import Header from './components/Header';
import ProductList from './components/ProductList';
import Footer from './components/Footer';
import Cart from './components/Cart';
import FeaturedProducts from './components/FeaturedProducts';
import { Product } from './types';

function App() {
  const [cartItems, setCartItems] = useState<Product[]>([]);
  const [showCart, setShowCart] = useState(false);

  const addToCart = (product: Product) => {
    setCartItems([...cartItems, product]);
  };

  const removeFromCart = (productId: number) => {
    setCartItems(cartItems.filter(item => item.id !== productId));
  };

  const toggleCart = () => {
    setShowCart(!showCart);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-900 text-gray-100">
      <Header cartItemCount={cartItems.length} toggleCart={toggleCart} />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-center text-purple-400 mb-2">Welcome to EzBuild</h1>
          <p className="text-center text-gray-300 max-w-2xl mx-auto">
            Your one-stop destination for premium gaming PCs at competitive prices. 
            Build your dream gaming setup with our high-performance custom builds.
          </p>
        </div>

        <FeaturedProducts addToCart={addToCart} />
        <ProductList addToCart={addToCart} />
      </main>

      <Footer />

      {showCart && (
        <Cart 
          cartItems={cartItems} 
          removeFromCart={removeFromCart} 
          closeCart={toggleCart} 
        />
      )}
    </div>
  );
}

export default App;