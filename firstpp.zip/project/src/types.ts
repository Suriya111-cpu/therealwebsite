export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  image: string;
  specs: {
    processor: string;
    graphics: string;
    ram: string;
    storage: string;
    cooling: string;
  };
}