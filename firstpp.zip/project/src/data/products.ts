import { Product } from '../types';

export const products: Product[] = [
  {
    id: 1,
    name: "Titan X Gaming PC",
    description: "High-end gaming PC with RTX 4080 and Intel Core i9 for ultimate gaming performance",
    price: 185999,
    image: "https://images.unsplash.com/photo-1587202372775-e229f172b9d7?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    specs: {
      processor: "Intel Core i9-13900K",
      graphics: "NVIDIA GeForce RTX 4080 16GB",
      ram: "32GB DDR5 5200MHz",
      storage: "2TB NVMe SSD",
      cooling: "360mm AIO Liquid Cooler"
    }
  },
  {
    id: 2,
    name: "Stealth Pro",
    description: "Mid-range gaming PC with excellent cooling and RGB lighting",
    price: 124999,
    image: "https://images.unsplash.com/photo-1593640408182-31c70c8268f5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    specs: {
      processor: "AMD Ryzen 7 7800X3D",
      graphics: "NVIDIA GeForce RTX 4070 12GB",
      ram: "16GB DDR5 4800MHz",
      storage: "1TB NVMe SSD",
      cooling: "240mm AIO Liquid Cooler"
    }
  },
  {
    id: 3,
    name: "Valor Mini",
    description: "Compact gaming PC with powerful components in a small form factor",
    price: 89999,
    image: "https://images.unsplash.com/photo-1625842268584-8f3296236761?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    specs: {
      processor: "Intel Core i5-13600K",
      graphics: "NVIDIA GeForce RTX 4060 Ti 8GB",
      ram: "16GB DDR5 4800MHz",
      storage: "1TB NVMe SSD",
      cooling: "Air Cooling"
    }
  },
  {
    id: 4,
    name: "Phantom Elite",
    description: "Premium gaming PC with custom water cooling and top-tier components",
    price: 249999,
    image: "https://images.unsplash.com/photo-1624705002806-5d72df19c3ad?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    specs: {
      processor: "AMD Ryzen 9 7950X",
      graphics: "NVIDIA GeForce RTX 4090 24GB",
      ram: "64GB DDR5 6000MHz",
      storage: "4TB NVMe SSD",
      cooling: "Custom Water Cooling Loop"
    }
  },
  {
    id: 5,
    name: "Horizon Basic",
    description: "Entry-level gaming PC for casual gamers on a budget",
    price: 59999,
    image: "https://images.unsplash.com/photo-1591488320449-011701bb6704?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    specs: {
      processor: "AMD Ryzen 5 7600X",
      graphics: "NVIDIA GeForce RTX 4060 8GB",
      ram: "16GB DDR5 4800MHz",
      storage: "512GB NVMe SSD",
      cooling: "Air Cooling"
    }
  },
  {
    id: 6,
    name: "Vortex Stream",
    description: "Gaming PC optimized for streaming and content creation",
    price: 149999,
    image: "https://images.unsplash.com/photo-1603481546238-487240415921?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    specs: {
      processor: "AMD Ryzen 9 7900X",
      graphics: "NVIDIA GeForce RTX 4070 Ti 16GB",
      ram: "32GB DDR5 5200MHz",
      storage: "2TB NVMe SSD",
      cooling: "280mm AIO Liquid Cooler"
    }
  },
  {
    id: 7,
    name: "Nexus Gaming",
    description: "Well-balanced gaming PC with great price-to-performance ratio",
    price: 104999,
    image: "https://images.unsplash.com/photo-1547082299-de196ea013d6?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    specs: {
      processor: "Intel Core i7-13700K",
      graphics: "NVIDIA GeForce RTX 4070 12GB",
      ram: "32GB DDR5 4800MHz",
      storage: "1TB NVMe SSD",
      cooling: "240mm AIO Liquid Cooler"
    }
  },
  {
    id: 8,
    name: "Eclipse Pro",
    description: "Silent gaming PC with noise-optimized components and case",
    price: 134999,
    image: "https://images.unsplash.com/photo-1587202372616-b43abea06c2a?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    specs: {
      processor: "Intel Core i7-13700K",
      graphics: "NVIDIA GeForce RTX 4070 Ti 16GB",
      ram: "32GB DDR5 4800MHz",
      storage: "2TB NVMe SSD",
      cooling: "Silent Air Cooling"
    }
  },
  {
    id: 9,
    name: "Zenith Extreme",
    description: "Enthusiast-grade gaming PC with dual GPUs for maximum performance",
    price: 299999,
    image: "https://images.unsplash.com/photo-1600348712270-5a8665a86e8a?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    specs: {
      processor: "Intel Core i9-13900KS",
      graphics: "Dual NVIDIA GeForce RTX 4080 16GB",
      ram: "128GB DDR5 6400MHz",
      storage: "4TB NVMe SSD + 8TB HDD",
      cooling: "Custom Water Cooling Loop"
    }
  },
  {
    id: 10,
    name: "Fusion Starter",
    description: "Affordable gaming PC with upgrade path for future enhancements",
    price: 74999,
    image: "https://images.unsplash.com/photo-1593152167544-085d3b9c4938?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    specs: {
      processor: "AMD Ryzen 5 7600",
      graphics: "NVIDIA GeForce RTX 4060 8GB",
      ram: "16GB DDR5 4800MHz",
      storage: "1TB NVMe SSD",
      cooling: "Air Cooling"
    }
  }
];